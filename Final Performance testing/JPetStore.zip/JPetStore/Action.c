Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

/*Correlation comment - Do not change!  Original value='DOGS' Name ='Category' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=Category",
		"RegExp=categories/(.*?)\">Dogs",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/jpetstore.aspectran.com/*",
		LAST);

	web_url("jpetstore.aspectran.com", 
		"URL=https://jpetstore.aspectran.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("category");

/*Correlation comment - Do not change!  Original value='K9-BD-01' Name ='ProductId' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=ProductId",
		"RegExp=products/(.*?)\">K9-BD-01",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("Dogs",
		"URL=https://jpetstore.aspectran.com/categories/{Category}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/",
		"Snapshot=t2.inf",
		"Mode=HTML",
		LAST);


	lr_end_transaction("category",LR_AUTO);

	lr_start_transaction("product");

/*Correlation comment - Do not change!  Original value='EST-33' Name ='itemId' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=itemId",
		"RegExp=items/(.*?)\">EST-33",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("K9-BD-01",
		"URL=https://jpetstore.aspectran.com/products/{ProductId}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/categories/{Category}",
		"Snapshot=t3.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("product",LR_AUTO);

	lr_start_transaction("cart");

	web_url("Add to Cart",
		"URL=https://jpetstore.aspectran.com/cart/addItemToCart?itemId={itemId}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/products/{ProductId}",
		"Snapshot=t4.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("cart",LR_AUTO);

	lr_start_transaction("checkout");

	web_url("Proceed to Checkout", 
		"URL=https://jpetstore.aspectran.com/order/newOrderForm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/cart/viewCart", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("checkout",LR_AUTO);

	lr_start_transaction("login");

	web_submit_data("signon", 
		"Action=https://jpetstore.aspectran.com/account/signon", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/account/signonForm?referer=/order/newOrderForm", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=referer", "Value=/order/newOrderForm", ENDITEM, 
		"Name=username", "Value={Username}", ENDITEM, 
		"Name=password", "Value={Password}", ENDITEM, 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("continue");

	web_submit_data("newOrder",
		"Action=https://jpetstore.aspectran.com/order/newOrder",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://jpetstore.aspectran.com/order/newOrderForm",
		"Snapshot=t7.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=paymentForm", "Value=true", ENDITEM,
		"Name=billingForm", "Value=true", ENDITEM,
		"Name=cardType", "Value={CardType}", ENDITEM,
		"Name=creditCard", "Value={CardNumber}", ENDITEM,
		"Name=expiryDate", "Value={Month}", ENDITEM,
		"Name=billToFirstName", "Value={FirstName}", ENDITEM,
		"Name=billToLastName", "Value={LastName}", ENDITEM,
		"Name=billAddress1", "Value={Address}", ENDITEM,
		"Name=billAddress2", "Value={Address2}", ENDITEM,
		"Name=billCity", "Value={City}", ENDITEM,
		"Name=billState", "Value={State}", ENDITEM,
		"Name=billZip", "Value={Zipcode}", ENDITEM,
		"Name=billCountry", "Value={Country}", ENDITEM,
		LAST);


	lr_end_transaction("continue",LR_AUTO);

	lr_start_transaction("confirm");

	web_submit_data("submitOrder", 
		"Action=https://jpetstore.aspectran.com/order/submitOrder", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://jpetstore.aspectran.com/order/newOrder", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=confirmed", "Value=true", ENDITEM, 
		LAST);

	lr_end_transaction("confirm",LR_AUTO);

	return 0;
}